<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
<meta charset="utf-8">


<link rel="stylesheet" href="style13.css">



</head>



<body>
<div class="firstpage" >

</div>



<form class="box"  action="intoo.php" method="POST">
<br><br><br><br><br><br>
<h1>User<br>
Login</h1>
<p style="text-align:center;color:#34495E;font-weight:bold;">Welcome to the website</p>

<i class="fa fa-user fa-lg"></i>
<input type="text" name="lname" placeholder="Username">
<i class="fa fa-lock fa-lg"></i>
<input type="password" name="lpass" placeholder="password">


<input type="submit" name="" value="Login">

<h3>
    Creat an account <a href=signup.php>Signup</a>
    <br><br>
    Admin <a href="../admin/adminlogin.php">Admin_login</a>
</h3>

</form>
</body>
</html>