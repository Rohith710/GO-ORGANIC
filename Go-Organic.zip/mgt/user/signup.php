<!DOCTYPE html>



<html lang="en" dir="ltr">

<head>
<meta charset="utf-8">
<link rel="stylesheet" href="style11.css">


</head>


<body>

<form class="box" action="sign.php" method="POST">





<h1 >User Signup</h1>




<h4>Name<input type="text" name="sname" placeholder ="Name"></h4>


<h4>Create Username<input type="text" name="suser" placeholder="Any Character"></h4>


<h4>Email<input type="text" name="sem" placeholder="email"></h4>
<h4>Mobile Number<input type="text" name="smb" placeholder="mobile"></h4>


<h4>Create password:<input type="password" name ="spass" placeholder= "Minimum 4 charecters"></h4>
<h4>District<input type="text" name="sids" placeholder ="District"></h4>


<h4>Address<input type="text" name="sadd" placeholder="Door.no/Area/Pin"></h4>



<input type="submit" name="signup" value="Signup & Continue">








</body>
</html>