<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
<meta charset="utf-8">


<link rel="stylesheet" href="../user/style13.css">



</head>



<body>
<div class="firstpage" >

</div>



<form class="box"  action="admininto.php" method="POST">
<br><br><br><br><br><br>
<h1>Admin<br>
Login</h1>
<p style="text-align:center;color:#34495E;font-weight:bold;">Welcome to the website</p>

<i class="fa fa-user fa-lg"></i>
<input type="text" name="Uname" placeholder="Username">
<i class="fa fa-lock fa-lg"></i>
<input type="password" name="Pass" placeholder="password">


<input type="submit" name="" value="Login">

</form>
</body>
</html>
       
</body>

</html>