<html>
<style>
        .tabs{
			text-transform: uppercase;
            background: #F68B1E;
            border: 1px solid #F68B1E;
            cursor: pointer;
            color: #fff;
            padding: 8px 40px;
            margin: 10px;
            width:50%;
		}
        body{
            background-image:url("bg.jpg");
            background-blend-mode: lighten;
            background-repeat:no-repeat;
            background-size:cover;
        }
</style>
    <link rel="stylesheet" href="review.css">
    <center><h1 style="color:black;font-size:50px;font-weight:bold;">GOrganic Admin page</h1></center>
    <div class="con">
     <div class="centerdiv">
     <div class="review-card">
     <center>
     <a href="addprod.html"><button name="add" class="tabs">Add a product</button></a><br><br>
    <a href="updateprod.html"><button name="update" class="tabs">Update price</button></a><br><br>
    <a href="removeprod.html"><button name="remove" class="tabs">Remove a product</button></a><br><br>
    <a href="products.php"><button name="products" class="tabs">View products</button></a><br><br>
    <a href="Allorders.php"><button name="allorders" class="tabs">All Orders</button></a><br><br>
    <a href="updatedelivery.html"><button name="updatedeliverey" class="tabs">Update Delivery</button></a><br><br>
    <a href="yet_to_deliver.php"><button name="yet_to_deliver" class="tabs">yet_to_deliver</button></a><br><br>
    <a href="deliveredorder.php"><button name="delivered" class="tabs">Delivered Orders</button></a><br><br></center>
     </div>
     </div>
    </div>
</html>



